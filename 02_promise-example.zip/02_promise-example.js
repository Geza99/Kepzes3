


function myFirstPromise( param  ) { 
    return new Promise( ( resolve, reject) =>  {
        if (param % 2 === 0) { 
            resolve(param); 
        }
        else {
            reject(param)
        }
    } )
}



myFirstPromise( 3 )
    .then( ( param ) => { console.log('Paros szam:  ' + param ) } )
    .catch(  (param ) => {console.log('Paratlan szam ' + param)  } )




















































